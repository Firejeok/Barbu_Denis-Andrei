
const canvas = document.getElementById('particle-canvas');
// Verifică dacă elementul canvas există
if (canvas) {
    const ctx = canvas.getContext('2d');
    let particles = [];
    
    // Culorile tale principale (folosite și în CSS)
    const PRIMARY_COLOR = '#04b3d2'; // Cyan
    const SECONDARY_COLOR = '#015871'; // Navy Blue

    // Configurări (poți schimba aceste valori)
    const NUM_PARTICLES = 100; // Numărul de particule
    const MAX_DISTANCE = 100; // Distanța maximă pentru a trasa o linie
    
    // Ajustează dimensiunea canvas-ului la dimensiunea ferestrei
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    // Constructor pentru o particulă
    class Particle {
        constructor() {
            // Poziție aleatorie
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            
            // Viteză mică și aleatorie
            this.vx = (Math.random() - 0.5) * 0.4; 
            this.vy = (Math.random() - 0.5) * 0.4;
            
            this.radius = Math.random() * 2 + 1; // Rază între 1 și 3
            this.color = Math.random() > 0.5 ? PRIMARY_COLOR : SECONDARY_COLOR;
        }

        // Metoda de desenare a particulei
        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fillStyle = this.color;
            ctx.fill();
        }

        // Metoda de actualizare a poziției și a marginilor (rebound)
        update() {
            this.x += this.vx;
            this.y += this.vy;

            if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
            if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
        }
    }

    // Inițializarea particulelor
    function init() {
        resizeCanvas();
        for (let i = 0; i < NUM_PARTICLES; i++) {
            particles.push(new Particle());
        }
    }

    // Funcția pentru desenarea liniilor între particule
    function drawLines() {
        for (let i = 0; i < NUM_PARTICLES; i++) {
            for (let j = i; j < NUM_PARTICLES; j++) {
                const p1 = particles[i];
                const p2 = particles[j];

                const dx = p1.x - p2.x;
                const dy = p1.y - p2.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < MAX_DISTANCE) {
                    const opacity = 1 - (distance / MAX_DISTANCE);
                    
                    ctx.beginPath();
                    // Folosim o culoare deschisă pentru linii (Cyan)
                    ctx.strokeStyle = `rgba(4, 179, 210, ${opacity})`; 
                    ctx.lineWidth = 1;
                    ctx.moveTo(p1.x, p1.y);
                    ctx.lineTo(p2.x, p2.y);
                    ctx.stroke();
                }
            }
        }
    }

    // Funcția principală de animație
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height); 
        
        drawLines();
        
        for (let i = 0; i < NUM_PARTICLES; i++) {
            particles[i].update();
            particles[i].draw();
        }

        requestAnimationFrame(animate); 
    }

    // Gestionează redimensionarea ferestrei
    window.addEventListener('resize', resizeCanvas);
    
    // Pornirea aplicației
    init();
    animate();
}

document.addEventListener('DOMContentLoaded', () => {
    setupCartLogic(); 
    setupParticleAnimation(); // Presupunând că ai funcția de animație definită
});


// --- Funcția de Bază a Logicii Coșului ---

function setupCartLogic() {
    // Verifică existența containerului principal (CartContainer)
    const cartContainer = document.querySelector('.cart-container');
    if (!cartContainer) return;

    // --- Definirea Elementelor DOM (Verifică ID-urile/Clasele din HTML!) ---
    const donationInput = document.getElementById('donation-amount');
    const subtotalDisplay = document.querySelector('.summary-line:nth-child(1) span:last-child');
    const totalDisplay = document.querySelector('.summary-line.total strong:last-child');
    const cartTable = document.querySelector('.cart-items table');

    // Verificare strictă a elementelor critice
    if (!donationInput || !subtotalDisplay || !totalDisplay || !cartTable) {
        console.error("Eroare Critică JS: Nu s-au putut găsi toate elementele de Sumar (ID/Class mismatch). Logica de calcul nu va rula.");
        return; 
    }

    // Constanta de Taxă (trebuie să se potrivească cu ce este afișat în HTML: 5 EUR)
    const PROCESSING_FEE = 5.00; 

    /**
     * Parsează un număr dintr-un input sau text, returnând 0 dacă eșuează.
     */
    function safeParseFloat(value) {
        const cleanValue = String(value).replace(',', '.');
        const num = parseFloat(cleanValue);
        return isNaN(num) ? 0 : num;
    }

    /**
     * Calculează și actualizează totalurile coșului.
     */
    function updateCartTotals() {
        let currentSubtotal = 0;
        let currentDonation = safeParseFloat(donationInput.value); 
        
        const allRows = document.querySelectorAll('.cart-items tbody tr');
        
        allRows.forEach(row => {
            
            // 1. CITIRE PREȚ UNITAR (din atributul data-price-unit al rândului <tr>)
            const unitPrice = safeParseFloat(row.dataset.priceUnit);
            
            // 2. CITIRE CANTITATE (din input-ul cu clasa item-quantity)
            const quantityInput = row.querySelector('.item-quantity');
            const quantity = quantityInput ? safeParseFloat(quantityInput.value) : 0;
            
            // 3. CALCUL
            const rowTotal = unitPrice * quantity;
            currentSubtotal += rowTotal;
            
            // 4. ACTUALIZARE TOTAL RÂND (coloana 4)
            const rowTotalCell = row.querySelector('td:nth-child(4)');
            if (rowTotalCell) {
                // Afișează Totalul formatat
                rowTotalCell.textContent = `${rowTotal.toFixed(2)} EUR`; 
            }
        });
        
        // Calculează Totalul Final
        const finalTotal = currentSubtotal + PROCESSING_FEE + currentDonation;

        // 5. Actualizează Sumarul
        subtotalDisplay.textContent = `${currentSubtotal.toFixed(2)} EUR`;
        totalDisplay.textContent = `${finalTotal.toFixed(2)} EUR`;
    }

    
    /**
     * Funcție pentru ștergerea unui articol
     */
    function removeItem(event) {
        if (event.target.classList.contains('remove-btn')) {
            event.preventDefault(); // Oprirea acțiunii default a butonului, dacă există
            const rowToRemove = event.target.closest('tr');
            
            if (rowToRemove) {
                rowToRemove.remove(); // Șterge rândul
                updateCartTotals();  // Recalculează totalurile
            }
        }
    }
    
    
    /**
     * Inițializarea Ascultătorilor de Evenimente
     */
    function setupListeners() {
        // Ascultă click-urile pe tabel pentru ștergere
        cartTable.addEventListener('click', removeItem);

        // Ascultă schimbările de valoare (Cantitate și Donație)
        cartTable.addEventListener('input', updateCartTotals);
        donationInput.addEventListener('input', updateCartTotals);
    }

    // --- Pornirea Logicii ---
    setupListeners();
    updateCartTotals(); // Execută o dată la încărcarea paginii pentru a inițializa afișajul
}