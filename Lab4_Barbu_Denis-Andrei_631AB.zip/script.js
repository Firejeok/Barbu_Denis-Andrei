
const inputActivitate = document.getElementById('inputActivitate');
const btnAdauga = document.getElementById('btnAdauga');
const listaActivitati = document.getElementById('listaActivitati');

const luni = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];


function adaugaActivitate() {
    const textActivitate = inputActivitate.value.trim();

    
    if (textActivitate !== "") {
    
        const elementNou = document.createElement('li');

        
        const dataCurenta = new Date();
        
        const zi = dataCurenta.getDate();
        
        const lunaText = luni[dataCurenta.getMonth()];
        const an = dataCurenta.getFullYear();

       
       
        const textAfisat = `${textActivitate} – adaugata la: ${zi} ${lunaText} ${an}`;

        
        elementNou.textContent = textAfisat;

        listaActivitati.appendChild(elementNou);

        inputActivitate.value = '';
    }
}

btnAdauga.addEventListener('click', adaugaActivitate);

inputActivitate.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        adaugaActivitate();
    }
});


