INSERT INTO studenti.mesaje_contact (id, nume, email, mesaj, data_trimiterii) VALUES (1, 'Denis Barbu', 'firejeok@gmail.com', 'aaa', '2026-01-19 00:51:57');
