INSERT INTO studenti.program_festival (id, ziua, ora_inceput, ora_sfarsit, nume_act, scena) VALUES (1, 'Vineri', '17:19', '18:19', 'Mero', 'Main Stage');
INSERT INTO studenti.program_festival (id, ziua, ora_inceput, ora_sfarsit, nume_act, scena) VALUES (2, 'Sambata', '23:15', '12:30', 'Lil Uzi Vert', 'Main Stage');
INSERT INTO studenti.program_festival (id, ziua, ora_inceput, ora_sfarsit, nume_act, scena) VALUES (3, 'Duminica', '23:15', '12:30', 'David Guetta', 'Main Stage');
INSERT INTO studenti.program_festival (id, ziua, ora_inceput, ora_sfarsit, nume_act, scena) VALUES (4, 'Duminica', '12:51', '01:45', 'The Weekend', 'Main Stage');
