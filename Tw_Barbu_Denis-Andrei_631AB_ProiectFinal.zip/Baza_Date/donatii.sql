INSERT INTO studenti.donatii (id, user_id, suma, mesaj, data_donatie) VALUES (1, 10, 100.00, 'Succes!', '2026-01-19 00:00:04');
INSERT INTO studenti.donatii (id, user_id, suma, mesaj, data_donatie) VALUES (2, 10, 100.00, 'Succes!', '2026-01-19 00:00:47');
INSERT INTO studenti.donatii (id, user_id, suma, mesaj, data_donatie) VALUES (3, 10, 100.00, 'Succes!', '2026-01-19 00:01:28');
INSERT INTO studenti.donatii (id, user_id, suma, mesaj, data_donatie) VALUES (4, 7, 100.00, 'Succes!', '2026-01-19 00:02:31');
INSERT INTO studenti.donatii (id, user_id, suma, mesaj, data_donatie) VALUES (5, 7, 100.00, 'Succes!', '2026-01-19 00:03:06');
INSERT INTO studenti.donatii (id, user_id, suma, mesaj, data_donatie) VALUES (6, 7, 100.00, 'Succes!', '2026-01-19 00:05:39');
INSERT INTO studenti.donatii (id, user_id, suma, mesaj, data_donatie) VALUES (7, 10, 50.00, 'Taree!!', '2026-01-19 00:10:24');
INSERT INTO studenti.donatii (id, user_id, suma, mesaj, data_donatie) VALUES (8, 7, 10.00, 'Alo?', '2026-01-19 00:10:48');
