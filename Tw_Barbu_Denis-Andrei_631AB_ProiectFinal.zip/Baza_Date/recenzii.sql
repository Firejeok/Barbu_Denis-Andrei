INSERT INTO studenti.recenzii (id, nume_utilizator, nota, comentariu, data_postarii) VALUES (2, 'Dana', 5, 'Dorect urmatoarea editie!', '2026-01-18 23:34:20');
